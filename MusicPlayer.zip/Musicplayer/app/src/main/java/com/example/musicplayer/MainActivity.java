package com.example.musicplayer;

import android.content.Intent;
import android.os.Bundle;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.musicplayer.adapters.SongAdapter;
import com.example.musicplayer.models.Song;
import com.example.musicplayer.utils.DatabaseHelper;
import com.example.musicplayer.utils.JsonUtils;

import java.util.List;

public class MainActivity extends AppCompatActivity {
    private RecyclerView recyclerView;
    private SongAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        recyclerView = findViewById(R.id.recyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        // Загрузка песен из JSON
        List<Song> songList = JsonUtils.loadSongs(this, R.raw.songs);

        adapter = new SongAdapter(songList, song -> {
            Intent intent = new Intent(MainActivity.this, SongDetailActivity.class);
            intent.putExtra("filePath", song.getFilePath());
            intent.putExtra("title", song.getTitle());
            intent.putExtra("artist", song.getArtist());
            startActivity(intent);
        });

        recyclerView.setAdapter(adapter);
    }
}