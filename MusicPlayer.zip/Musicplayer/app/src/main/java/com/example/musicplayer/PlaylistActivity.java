package com.example.musicplayer;

import android.os.Bundle;
import android.widget.Button;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import java.io.File; // Для работы с классом File
import com.example.musicplayer.utils.PlaylistExportUtils; // Для экспорта плейлиста
import com.example.musicplayer.models.Song;
import com.example.musicplayer.utils.DatabaseHelper;

import java.util.List;

public class PlaylistActivity extends AppCompatActivity {
    private DatabaseHelper db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_playlist);

        db = new DatabaseHelper(this);

        Button exportButton = findViewById(R.id.exportButton);
        exportButton.setOnClickListener(v -> {
            List<Song> songs = db.getAllSongs();
            File exportedFile = PlaylistExportUtils.exportPlaylistToJson(this, songs);
            if (exportedFile != null) {
                Toast.makeText(this, "Playlist exported to: " + exportedFile.getAbsolutePath(), Toast.LENGTH_LONG).show();
            } else {
                Toast.makeText(this, "Failed to export playlist.", Toast.LENGTH_SHORT).show();
            }
        });
    }
}