package com.example.musicplayer;

import android.content.ComponentName;
import android.content.Intent;
import android.content.ServiceConnection;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.os.IBinder;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class SongDetailActivity extends AppCompatActivity {
    private MediaPlayer mediaPlayer;
    private boolean isPlaying = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_song_detail);

        TextView titleTextView = findViewById(R.id.songTitleDetail);
        TextView artistTextView = findViewById(R.id.songArtistDetail);
        Button playPauseButton = findViewById(R.id.playPauseButton);
        Button stopButton = findViewById(R.id.stopButton);

        // Получение данных из Intent
        String filePath = getIntent().getStringExtra("filePath");
        String title = getIntent().getStringExtra("title");
        String artist = getIntent().getStringExtra("artist");

        titleTextView.setText(title);
        artistTextView.setText(artist);

        // Инициализация MediaPlayer
        int resourceId = getResources().getIdentifier(filePath, "raw", getPackageName());
        if (resourceId != 0) {
            mediaPlayer = MediaPlayer.create(this, resourceId);
        } else {
            Toast.makeText(this, "Файл не найден!", Toast.LENGTH_SHORT).show();
        }

        // Кнопка Play/Pause
        playPauseButton.setOnClickListener(v -> {
            if (mediaPlayer != null) {
                if (isPlaying) {
                    mediaPlayer.pause();
                    playPauseButton.setText("Play");
                } else {
                    mediaPlayer.start();
                    playPauseButton.setText("Pause");
                }
                isPlaying = !isPlaying;
            }
        });

        // Кнопка Stop
        stopButton.setOnClickListener(v -> {
            if (mediaPlayer != null) {
                mediaPlayer.stop();
                mediaPlayer.reset();
                mediaPlayer.release();
                mediaPlayer = null;
                isPlaying = false;
                playPauseButton.setText("Play");
            }
        });
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (mediaPlayer != null) {
            mediaPlayer.release();
            mediaPlayer = null;
        }
    }
}