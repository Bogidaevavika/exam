package com.example.musicplayer.utils;

import android.content.Context;

import com.example.musicplayer.models.Song;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

public class JsonUtils {
    public static List<Song> loadSongs(Context context, int rawResourceId) {
        List<Song> songs = new ArrayList<>();
        try {
            InputStream is = context.getResources().openRawResource(rawResourceId);
            byte[] buffer = new byte[is.available()];
            is.read(buffer);
            is.close();
            String json = new String(buffer, "UTF-8");

            JSONArray jsonArray = new JSONArray(json);
            for (int i = 0; i < jsonArray.length(); i++) {
                JSONObject obj = jsonArray.getJSONObject(i);
                songs.add(new Song(
                        obj.getString("title"),
                        obj.getString("artist"),
                        obj.getString("filePath")
                ));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return songs;
    }
}