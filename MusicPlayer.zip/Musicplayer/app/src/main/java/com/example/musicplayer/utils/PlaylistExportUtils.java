package com.example.musicplayer.utils;
import android.content.Context;

import com.example.musicplayer.models.Song;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.File; // Для работы с классом File
import java.io.FileWriter;
import java.util.List;

public class PlaylistExportUtils {

    public static File exportPlaylistToJson(Context context, List<Song> songs) {
        File exportFile = new File(context.getExternalFilesDir(null), "playlist.json");

        try {
            JSONArray jsonArray = new JSONArray();
            for (Song song : songs) {
                JSONObject songJson = new JSONObject();
                songJson.put("title", song.getTitle());
                songJson.put("artist", song.getArtist());
                songJson.put("filePath", song.getFilePath());
                jsonArray.put(songJson);
            }

            FileWriter writer = new FileWriter(exportFile);
            writer.write(jsonArray.toString());
            writer.close();

        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
        return exportFile;
    }
}